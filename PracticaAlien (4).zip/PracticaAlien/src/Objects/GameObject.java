package Objects;
//importar random

import java.io.Serializable;
import java.util.Random;


public class GameObject implements Serializable {
    private String name;
    private String id;
    private final int health;
    private final int strength;
    private int y;
    private int x;


    public GameObject(String name, int health, int strength, int x, int y) {
        this.name = name;
        this.health = health;
        this.strength = strength;
        this.x = x;
        this.y = y;
        this.id = "o";
    }

    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }

    public int getStrength() {
        return strength;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getY() {
        return y;
    }


    public int getX() {
        return x;
    }

}

