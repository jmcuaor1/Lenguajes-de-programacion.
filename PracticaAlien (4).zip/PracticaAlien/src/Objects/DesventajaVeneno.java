package Objects;

public class DesventajaVeneno extends GameObject{

    public DesventajaVeneno(int x, int y) {
        super("Veneno", 0, -5, x, y);
    }

}
