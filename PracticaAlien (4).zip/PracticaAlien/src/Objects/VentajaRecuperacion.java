package Objects;

public class VentajaRecuperacion extends GameObject{

    public VentajaRecuperacion(int x, int y) {
        super("Recuperacion", 5, 0, x, y);
    }

}
