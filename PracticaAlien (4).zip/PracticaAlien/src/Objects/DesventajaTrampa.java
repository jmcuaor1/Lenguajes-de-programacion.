package Objects;

public class DesventajaTrampa extends GameObject{

    public DesventajaTrampa(int x, int y) {
        super("Trampa", -5, 0, x, y);
    }
}
