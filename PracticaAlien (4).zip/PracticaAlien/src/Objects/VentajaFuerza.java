package Objects;

public class VentajaFuerza extends GameObject{
    public VentajaFuerza(int x, int y) {
        super("Fuerza", 0,5, x, y);
    }
}
