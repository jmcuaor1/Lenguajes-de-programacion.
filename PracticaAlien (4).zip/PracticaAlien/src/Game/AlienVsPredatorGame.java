package Game;

import Characters.Character;
import Objects.*;
import util.Directions;
import Characters.*;

import java.io.*;

import java.util.Scanner;
import java.util.Random;


public class AlienVsPredatorGame {
    private GameMap gameMap;
    private Alien alien;
    private Predator predator;
    private final Random random;
    private final Scanner scanner;

    private String characterChoice;

    public AlienVsPredatorGame() {
        this.scanner = new Scanner(System.in);
        this.random = new Random();
    }

    public void start() {
        //preguntar si se quiere cargar partida
        System.out.println("Quieres Cargar algun archivo guardado? (Y/N)");
        String loadGame = this.scanner.nextLine();
        if (loadGame.equalsIgnoreCase("Y")) {
            this.loadGame();
            System.out.println("Partida Cargada");
            this.gameMap.displayMap();
            this.gameLoop();
            this.scanner.close();
        } else {
            this.newGame();
        }
    }

    private void newGame() {
        System.out.println("Nueva Partida Iniciada");
        this.getMapSize();
        this.generateObjects();
        this.generateCharacters();
        this.gameMap.displayMap();
        this.gameLoop();
    }

    private void getMapSize() {
        System.out.println("Elige el Tamaño del mapa (mxn) (Minimo 4x4 para el correcto funcionamiento del juego: ");
        System.out.print("Filas: ");
        int rows = Integer.parseInt(this.scanner.nextLine());
        System.out.print("Columnas: ");
        int columns = Integer.parseInt(this.scanner.nextLine());
        if (rows < 4 || columns < 4) {
            System.out.println("El tamaño minimo es de 4x4");
            this.getMapSize();
        } else {
            this.gameMap = new GameMap(rows, columns);
            this.gameMap.initializeMap();
        }
    }

    private void generateObjects() {
        int numberOfObjects = 4;
        GameObject[] gameObject = new GameObject[numberOfObjects];
        for (int i = 0; i < numberOfObjects; i++) {
            int randomRow = this.random.nextInt(this.gameMap.getWidth());
            int randomColumn = this.random.nextInt(this.gameMap.getHeight());
            int randomType = this.random.nextInt(4);
            switch (randomType) {
                case 0 -> gameObject[i] = new VentajaFuerza(randomRow, randomColumn);
                case 1 -> gameObject[i] = new VentajaRecuperacion(randomRow, randomColumn);
                case 2 -> gameObject[i] = new DesventajaTrampa(randomRow, randomColumn);
                case 3 -> gameObject[i] = new DesventajaVeneno(randomRow, randomColumn);
            }
            this.gameMap.addGameObject(gameObject[i]);
        }
    }


    private void generateCharacters() {
        this.predator = new Predator(this.gameMap.getWidth() - 1, this.gameMap.getHeight() - 1);
        this.gameMap.addCharacter(this.predator);
        this.alien = new Alien(0, 0);
        this.gameMap.addCharacter(this.alien);
        chooseCharacter();
    }

    private void chooseCharacter() {
        do {
            System.out.println("Elije tu Personaje: ");
            System.out.println("1. Alien");
            System.out.println("2. Predator");
            this.characterChoice = this.scanner.nextLine();
            switch (this.characterChoice) {
                case "1" -> this.characterChoice = this.alien.getName();
                case "2" -> this.characterChoice = this.predator.getName();
                default -> System.out.println("Opcion Invalida");
            }
        } while (!this.characterChoice.equals(alien.getName()) && !this.characterChoice.equals(predator.getName()));
    }


    private void gameLoop() {
        while (this.alien.getLife() > 0 && this.predator.getLife() > 0) {
            //hacer que el jugador tenga el primer turno
            this.getTurnos();
            this.gameMap.displayMap();
            this.displayCharacters();
            System.out.println("Quieres Guardar el Juego? (yes/no)");
            String saveChoice = this.scanner.nextLine();
            if (saveChoice.equals("yes")) {
                this.saveGame();
                System.out.println("Juego Guardado");
                break;
            }

        }
        if (this.alien.getLife() <= 0) {
            this.printWinner(this.predator.getName());
        } else if (this.predator.getLife() <= 0) {
            this.printWinner(this.alien.getName());
        }
    }

    private void printWinner(String winner) {
        System.out.println("█▀▀█ ░█─░█ ▄█─█▄ █▀▀█ ▀█▀ ▀█▀ ▀▀█▀▀ █▀▀█ ▀▀█▀▀");
        System.out.println("─▀▀█ ░█▀▀█ ░█▀▀█ ░░█░░ ░█░ ░█░ ░░█░░ ░░█░░");
        System.out.println("▀▀▀▀ ░█─░█ ░█─░█ ░░▀░░ ░▀░ ░▀░ ░░▀░░ ░░▀░░");
        System.out.println("El ganador es: " + winner);
        System.out.println("█▄█─█▀▀█ ▄█─█▄ █▀▀█ ▀█▀ ▀█▀ ▀▀█▀▀ █▀▀█ ▀▀█▀▀");
        System.out.println("░█░░░█▀▀▄ ░█▀▀█ ░░█░░ ░█░ ░█░ ░░█░░ ░░█░░");
        System.out.println("░█░░░█▄▄█ ░█─░█ ░░▀░░ ░▀░ ░▀░ ░░▀░░ ░░▀░░");
    }

    private void getTurnos() {
        if (this.characterChoice.equals(this.alien.getName())) {
            this.alienTurn();
            this.predatorTurn();
        } else {
            this.predatorTurn();
            this.alienTurn();
        }
    }


    private void alienTurn() {
        // Decoración con barras ajustadas al nombre del personaje "Alien"
        String banner = "█ Alien's Turn █";
        int bannerLength = banner.length();

        StringBuilder separator = new StringBuilder("═".repeat(bannerLength));

        System.out.println(separator);
        System.out.println(banner);
        System.out.println(separator);

        if (this.characterChoice.equals(this.alien.getName())) {
            this.getAccion(alien);
        } else {
            alienRandomAction();
        }
    }

    private void alienRandomAction() {
        int randomChoice = this.random.nextInt(2);
        if (randomChoice == 0) {
            this.characterRandomMove(this.alien);
        } else {
            this.alien.specialAttackRandom(this.gameMap);
        }
    }

    private void predatorTurn() {
        // Decoración con barras ajustadas al nombre del personaje "Predator"
        String banner = "█ Predator's Turn █";
        int bannerLength = banner.length();

        StringBuilder separator = new StringBuilder("═".repeat(bannerLength));

        System.out.println(separator);
        System.out.println(banner);
        System.out.println(separator);

        if (this.characterChoice.equals(this.predator.getName())) {
            this.getAccion(predator);
        } else {
            predatorRandomAction();
        }
    }


    private void predatorRandomAction() {
        int randomChoice = this.random.nextInt(2);
        if (randomChoice == 0) {
            this.characterRandomMove(this.predator);
        } else {
            this.predator.specialAttack(this.alien);
        }
    }

    private void getAccion(Character character) {
        String eleccion = "";
        while (!eleccion.equals("1") && !eleccion.equals("2")) {
            System.out.println("Choose an action: ");
            System.out.println("1. Moverse");
            System.out.println("2. Utilizar la habilidad especial");
            eleccion = this.scanner.nextLine();
            if (!eleccion.equals("1") && !eleccion.equals("2")) {
                System.out.println("Opcion invalida");
            }
        }
        switch (eleccion) {
            case "1" -> characterMove(character);
            case "2" -> {
                if (character.getName().equals(this.alien.getName())) {
                    this.alien.specialAttack(this.gameMap);
                } else {
                    this.predator.specialAttack(this.alien);
                }
            }
        }
    }

    private Directions getDirection() {
        String eleccion = "";
        Directions directions = null;
        while (!eleccion.equals("w") && !eleccion.equals("a") && !eleccion.equals("s") && !eleccion.equals("d")) {
            System.out.println("Seleccione un movimiento: ");
            System.out.println("w. Arriba");
            System.out.println("a. Izquierda");
            System.out.println("s. Abajo");
            System.out.println("d. Derecha");
            eleccion = this.scanner.nextLine();
        }
        directions = switch (eleccion) {
            case "a" -> Directions.ARRIBA;
            case "w" -> Directions.IZQUIERDA;
            case "d" -> Directions.ABAJO;
            case "s" -> Directions.DERECHA;
            default -> null;
        };
        return directions;
    }


    //Alien moves using Direction enum
    public void characterMove(Character character) {
        //Predator cant move if the position is blocked

        this.gameMap.removeCharacter(character);
        character.verificarAtaque(character == this.alien ? this.predator : this.alien, this.getDirection(), this.gameMap);
        this.gameMap.addCharacter(character);
    }

    public void characterRandomMove(Character character) {
        Directions[] directions = Directions.values();
        int randomDirection = this.random.nextInt(directions.length);
        this.gameMap.removeCharacter(character);
        character.verificarAtaque(character == this.alien ? this.predator : this.alien, directions[randomDirection], this.gameMap);
        this.gameMap.addCharacter(character);
    }


    private void displayCharacters() {
        int boxWidth = 50; // Ancho de la caja
        char horizontalLine = '═'; // Carácter horizontal para el borde
        char verticalLine = '║'; // Carácter vertical para el borde

        // Imprimir borde superior
        System.out.print("╔");
        for (int i = 0; i < boxWidth - 2; i++) {
            System.out.print(horizontalLine);
        }
        System.out.println("╗");

        // Imprimir contenido
        String[] lines = {
                "⭐Vida del Alien: " + this.alien.getLife() + "❤️",
                "⭐Vida del Predator: " + this.predator.getLife() + "❤️",
                "═════════════════════════════════════════════",
                "⚡ Posición del Predator: (" + this.predator.getPositionY() + ", " + this.predator.getPositionX() + ")",
                "⚡ Posición del Alien: (" + this.alien.getPositionY() + ", " + this.alien.getPositionX() + ")"
        };

        for (String line : lines) {
            System.out.print(verticalLine + " " + line);
            int spacesToAdd = boxWidth - 4 - line.length(); // Espacios para alinear a la derecha
            for (int i = 0; i < spacesToAdd; i++) {
                System.out.print(" ");
            }
            System.out.println(" " + verticalLine);
        }

        // Imprimir borde inferior
        System.out.print("╚");
        for (int i = 0; i < boxWidth - 2; i++) {
            System.out.print(horizontalLine);
        }
        System.out.println("╝");
    }


    //metodo para guardar la partida


    //metodo para cargar la partida. pedirle al usuario el nombre del archivo y verificar si existe, si lo hace se sobreescribe el mapa y los personajes
    //verificar si la extension del archivo es .txt
    public void loadGame() {
        System.out.println("Insert the name of the file: ");
        String fileName = this.scanner.nextLine().trim();
        try {
            FileInputStream file = new FileInputStream(fileName);
            ObjectInputStream input = new ObjectInputStream(file);
            this.gameMap = (GameMap) input.readObject();
            this.alien = (Alien) input.readObject();
            this.predator = (Predator) input.readObject();
            this.characterChoice = (String) input.readObject();
            input.close();
            file.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("El archivo no existe o no es valido, creando un nuevo juego");
            this.newGame();
        }
    }


    //Guardar Un Archivo, pedirle al usuario el nombre del archivo
    public void saveGame() {
        System.out.println("Insertar el nombre del archivo(finaliza con .txt):  ");
        String fileName = this.scanner.nextLine().trim();
        //Verificar si la extension del archivo es .txt
        if (!fileName.endsWith(".txt")) {
            System.out.println("Nombre invalido, el archivo debe finalizar con .txt");
            return;
        }
        try {
            FileOutputStream file = new FileOutputStream(fileName);
            ObjectOutputStream output = new ObjectOutputStream(file);
            output.writeObject(this.gameMap);
            output.writeObject(this.alien);
            output.writeObject(this.predator);
            output.writeObject(this.characterChoice);
            output.close();
            file.close();
            System.out.println("La partida ha sido guardada exitosamente.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}