package Game;

import Objects.GameObject;
import Characters.Character;

import java.io.Serializable;
import java.util.Objects;

public class GameMap implements Serializable {

    int width;
    int height;
    int items = 0;
    String[][] map;
    GameObject[] objects = new GameObject[4];


    public GameMap(int mapWidth, int mapHeight) {
        this.width = mapWidth;
        this.height = mapHeight;
        this.map = new String[mapWidth][mapHeight];
    }

    public void initializeMap() {
        for (int i = 0; i < this.width; i++) {
            for (int j = 0; j < this.height; j++) {
                this.map[i][j] = ".";
            }
        }
    }

    public void addGameObject(GameObject gameObject) {
        this.map[gameObject.getX()][gameObject.getY()] = gameObject.getId();
        this.objects[this.items] = gameObject;
        this.items++;
    }

    public void addCharacter(Character character) {
        //El predador no puede pasar por los bloqueos "#"
        if (this.map[character.getPositionX()][character.getPositionY()].equals("o")) {
            character.usarObjeto(this.objects[this.items - 1]);
            this.items--;
        }
        this.map[character.getPositionX()][character.getPositionY()] = character.getId();
    }

    public void removeCharacter(Character character) {
        this.map[character.getPositionX()][character.getPositionY()] = ".";
    }

    public void addBlock(int x, int y, String id) {
        this.map[x][y] = id;
    }

    public void removeGameObject(GameObject gameObject) {
        this.map[gameObject.getX()][gameObject.getY()] = ".";
    }

    public void displayMap() {
        // Ancho de cada celda en el tablero (por defecto, 3 caracteres)
        int cellWidth = 3;

        // Caracteres para el borde superior e inferior
        char horizontalLine = '═';
        char topLeftCorner = '╔';
        char topRightCorner = '╗';
        char bottomLeftCorner = '╚';
        char bottomRightCorner = '╝';

        // Calcular la longitud total del borde superior e inferior
        int borderLength = (cellWidth) * (this.getWidth())+2; // +2 para incluir los caracteres de borde (║ y espacio)

        // Imprimir el borde superior
        System.out.print(topLeftCorner);
        for (int i = 0; i <= borderLength; i++) {
            System.out.print(horizontalLine);
        }
        System.out.println(topRightCorner);

        // Imprimir las filas del tablero con sus celdas
        for (int i = 0; i < this.width; i++) {
            System.out.print("║");
            for (int j = 0; j < this.height; j++) {
                String cellValue = " " + this.map[i][j] + " ";
                System.out.print(cellValue);
            }
            System.out.println("║");
        }

        // Imprimir el borde inferior
        System.out.print(bottomLeftCorner);
        for (int i = 0; i < borderLength; i++) {
            System.out.print(horizontalLine);
        }
        System.out.println(bottomRightCorner);
    }



    public String[][] getMap() {
        return map;
    }


    public int getWidth() {
        return width;
    }


    public int getHeight() {
        return height;
    }
}
