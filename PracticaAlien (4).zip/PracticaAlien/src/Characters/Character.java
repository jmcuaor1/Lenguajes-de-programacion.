package Characters;

import util.Directions;
import Objects.GameObject;
import Game.GameMap;

import java.io.Serializable;

public abstract class Character implements Serializable {

    public String getName() {
        return name;
    }

    String name;

    String id;
    int life;
    int attack;

    int positionX;
    int positionY;

    public Character(String name, String id, int positionX, int positionY) {
        this.name = name;
        this.life = 50;
        this.attack = 10;
        this.positionX = positionX;
        this.positionY = positionY;
        this.id = id;
    }


    public void mover(Directions direction, GameMap gameMap) {
        int newX = this.getPositionX();
        int newY = this.getPositionY();
        int limiteDerecho = gameMap.getWidth() - 1;
        int limiteInferior = gameMap.getHeight() - 1;

        switch (direction) {
            case ARRIBA -> newY--;
            case ABAJO -> newY++;
            case IZQUIERDA -> newX--;
            case DERECHA -> newX++;
        }

        // Verifica si la nueva posición está dentro de los límites
        if (newX <= limiteDerecho && newY <= limiteInferior && newX >= 0 && newY >= 0) {
            // Verifica si la nueva posición está bloqueada
            if (!gameMap.getMap()[newX][newY].equals("#")) {
                positionX = newX;
                positionY = newY;
                System.out.println("El " + this.name + " se mueve a la posición (" + this.positionX + "," + this.positionY + ")");
            } else {
                System.out.println("El " + this.name + " no se puede mover a la posición (" + newX + "," + newY + ") porque hay un bloqueo");
            }
        } else {
            System.out.println("El " + this.name + " no se puede mover a la posición (" + newX + "," + newY + ")");
            System.out.println("El " + this.name + " se queda en la posición (" + this.positionX + "," + this.positionY + ")");
            System.out.println("Los límites son: (" + limiteDerecho + "," + limiteInferior + ")" + "y (0,0)");
        }
    }
    public void verificarAtaque(Character character, Directions direction, GameMap gameMap) {
        // Calcula las nuevas coordenadas
        int newX = this.getPositionX();
        int newY = this.getPositionY();

        switch (direction) {
            case ARRIBA -> newY--;
            case ABAJO -> newY++;
            case IZQUIERDA -> newX--;
            case DERECHA -> newX++;
        }

        // Verifica si el personaje a atacar está en las coordenadas nuevas
        if (character.positionX == newX && character.positionY == newY) {
            attack(character);
        } else {
            mover(direction, gameMap);
        }
    }


    public void attack(Character character) {
        character.life -= this.attack;
        System.out.println("El " + this.name + " ataca al " + character.name + " y le quita " + this.attack + " puntos de vida");
    }

    public void usarObjeto(GameObject gameObject) {
        this.setAttack(this.getAttack() + gameObject.getStrength());
        this.setLife(this.getLife() + gameObject.getHealth());
        if (gameObject.getName().equals("Fuerza") || gameObject.getName().equals("Recuperacion")) {
            System.out.println("El " + this.name + " usa " + gameObject.getName() + " y aumenta su ataque a " + this.attack + " y aumenta su vida a " + this.life);
        } else {
            System.out.println("El " + this.name + " usa " + gameObject.getName() + " y disminuye su vida a " + this.life + " y su ataque a " + this.attack);
        }
    }


    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getPositionX() {
        return positionX;
    }


    public int getPositionY() {
        return positionY;
    }

    public void getPositionY(int positionY) {
        this.positionY = positionY;
    }

    public abstract void specialAttack(Character character);

    public String getId() {
        return id;
    }


}
