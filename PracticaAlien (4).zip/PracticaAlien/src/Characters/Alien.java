package Characters;

import Game.GameMap;

import java.util.Scanner;

public class Alien extends Character {

    private final String block;

    public Alien(int positionX, int positionY) {
        super("Alien", "X", positionX, positionY);
        this.block = "#";
    }


    public String getBlock() {
        return block;
    }

    //Cada personaje tiene una ataque especial: el Alien puede ubicar bloqueos por
    //donde el Depredador no podrá pasar pero él sí. Estos bloques se representan con
    //un “#” en el mapa.

    public void specialAttack(GameMap gameMap) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ïnseta las coordenadas del bloqueo");
        System.out.println("Coordenada X: ");
        int x = scanner.nextInt();
        System.out.println("Coordenada Y: ");
        int y = scanner.nextInt();
        if (x >= 0 && x < gameMap.getWidth() && y >= 0 && y < gameMap.getHeight() && gameMap.getMap()[x][y].equals("."))
        {
            gameMap.addBlock(x, y, getBlock());
            System.out.println("El bloqueo se ha colocado en la posición (" + x + "," + y + ")");
        } else{
            System.out.println("No se puede colocar un bloqueo en la posición (" + x + "," + y + ") pues ya hay un objeto/enemigo o está fuera de los límites del mapa");
            System.out.println("El turno ha sido perdido");

        }
    }

    public void specialAttackRandom(GameMap gameMap) {
        int x = (int) (Math.random() * gameMap.getWidth());
        int y = (int) (Math.random() * gameMap.getHeight());
        if (gameMap.getMap()[x][y].equals("."))
        {
            gameMap.addBlock(x, y, getBlock());
            System.out.println("El alien ha utilizado su habilidad especial, el bloqueo se ha colocado en la posición (" + x + "," + y + ")");

        } else{
            System.out.println("No se puede colocar un bloqueo en la posición aleatoria (" + x + "," + y + ") pues ya hay un objeto/enemigo o está fuera de los límites del mapa");
            System.out.println("El turno ha sido perdido");

        }
    }


    @Override
    public void specialAttack(Character character) {

    }


}
