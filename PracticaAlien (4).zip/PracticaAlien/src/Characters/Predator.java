package Characters;


public class Predator extends Character {

    public Predator(int positionX, int positionY) {
        super("Predator", "Y", positionX, positionY);
    }


    @Override
    public void specialAttack(Character character) {
        if (character instanceof Alien) {
            if (character.positionY == this.positionY) {
                character.life -= this.attack;
                System.out.println("El " + this.name + " ataca a distancia al " + character.name + " y le quita " + this.attack + " puntos de vida");
            }
        }
        System.out.println("El " + this.name + " Ha utilizado su ataque especial");
    }

    //El Depredador no puede moverse si hay un bloqueo en la dirección en la que quiere


}
