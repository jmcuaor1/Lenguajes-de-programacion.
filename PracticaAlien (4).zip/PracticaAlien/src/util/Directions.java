package util;

public enum Directions {
    ARRIBA, ABAJO, IZQUIERDA, DERECHA;
}
